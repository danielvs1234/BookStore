package com.schmidt.Model;

public class Author extends Person {


    public Author() {
    }
}
